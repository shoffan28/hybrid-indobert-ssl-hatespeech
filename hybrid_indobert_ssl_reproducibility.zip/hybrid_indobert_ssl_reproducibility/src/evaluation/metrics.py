import numpy as np
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score

def evaluate_predictions(y_true, y_pred, y_prob=None):
    out = {
        "accuracy": accuracy_score(y_true, y_pred),
        "macro_f1": f1_score(y_true, y_pred, average="macro"),
        "macro_precision": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "macro_recall": recall_score(y_true, y_pred, average="macro", zero_division=0),
    }
    try:
        out["roc_auc"] = roc_auc_score(y_true, y_prob) if y_prob is not None else np.nan
    except Exception:
        out["roc_auc"] = np.nan
    return out

def find_best_threshold(y_true, y_prob, start=0.2, stop=0.8, step=0.02):
    best_t, best_f1 = 0.5, -1
    for t in np.arange(start, stop + 1e-9, step):
        pred = (y_prob >= t).astype(int)
        f1 = f1_score(y_true, pred, average="macro")
        if f1 > best_f1:
            best_f1, best_t = f1, float(t)
    return best_t
