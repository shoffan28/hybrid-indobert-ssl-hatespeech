import re
import pandas as pd

def extract_handcrafted_features(texts, abusive_words=None):
    abusive_words = abusive_words or set()
    rows = []
    for text in texts:
        s = str(text)
        tokens = s.split()
        n_tok = max(len(tokens), 1)
        abusive_count = sum(1 for t in tokens if t.lower() in abusive_words)
        rows.append([
            abusive_count,
            abusive_count / n_tok,
            len(re.findall(r"[!?.,]", s)),
            sum(1 for c in s if c.isupper()) / max(len(s), 1),
            len(re.findall(r"(.)\\1{2,}", s)),
            sum(c.isdigit() for c in s),
            len(s),
            n_tok,
        ])
    return pd.DataFrame(rows, columns=[
        "abusive_count", "abusive_ratio", "punct_count", "upper_ratio",
        "repeat_chars", "digit_count", "char_len", "token_len"
    ])
