from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import Pipeline, FeatureUnion

def build_tfidf_svd_pipeline(cfg):
    word_pipe = Pipeline([
        ("tfidf", TfidfVectorizer(analyzer="word", ngram_range=(1, 2), max_features=cfg["features"]["word_tfidf_max_features"], min_df=2)),
        ("svd", TruncatedSVD(n_components=cfg["features"]["word_svd_dim"], random_state=cfg["seed"]))
    ])
    char_pipe = Pipeline([
        ("tfidf", TfidfVectorizer(analyzer="char", ngram_range=(3, 5), max_features=cfg["features"]["char_tfidf_max_features"], min_df=2)),
        ("svd", TruncatedSVD(n_components=cfg["features"]["char_svd_dim"], random_state=cfg["seed"]))
    ])
    return FeatureUnion([("word", word_pipe), ("char", char_pipe)])
