import pandas as pd
from sklearn.model_selection import train_test_split
from .preprocess import preprocess_text, load_kamusalay_dict, load_abusive_lexicon

def _standardize_columns(df, text_col, label_col):
    out = df[[text_col, label_col]].dropna().copy()
    out.columns = ["text", "label"]
    out["label"] = out["label"].astype(int)
    return out

def load_idhsd_dataset(path):
    df = pd.read_csv(path, sep="\t", encoding="utf-8", engine="python")
    text_col = "Tweet" if "Tweet" in df.columns else df.columns[0]
    label_col = "HS" if "HS" in df.columns else df.columns[-1]
    return _standardize_columns(df, text_col, label_col)

def load_572_dataset(path):
    df = pd.read_csv(path, encoding="utf-8")
    text_col = "text" if "text" in df.columns else df.columns[0]
    label_col = "label" if "label" in df.columns else df.columns[-1]
    return _standardize_columns(df, text_col, label_col)

def load_re_dataset(path):
    df = pd.read_csv(path, encoding="utf-8")
    text_col = "Tweet" if "Tweet" in df.columns else ("text" if "text" in df.columns else df.columns[0])
    label_col = "HS" if "HS" in df.columns else ("label" if "label" in df.columns else df.columns[-1])
    return _standardize_columns(df, text_col, label_col)

def prepare_full_dataset(cfg):
    paths = cfg["paths"]
    slang = load_kamusalay_dict(paths["kamusalay"])
    abusive_words = load_abusive_lexicon(paths["abusive"])
    data = pd.concat([
        load_idhsd_dataset(paths["idhsd"]),
        load_572_dataset(paths["hs572"]),
        load_re_dataset(paths["re_dataset"]),
    ], ignore_index=True)
    data = data.drop_duplicates(subset=["text"]).reset_index(drop=True)
    data["clean_text"] = data["text"].apply(lambda x: preprocess_text(x, slang))
    data = data[data["clean_text"].str.len() > 2].reset_index(drop=True)
    return data, abusive_words

def make_splits(data, cfg, seed=42):
    y = data[cfg["data"]["label_col"]]
    train_val, test = train_test_split(data, test_size=cfg["data"]["test_size"], stratify=y, random_state=seed)
    train, val = train_test_split(train_val, test_size=cfg["data"]["val_size"], stratify=train_val[cfg["data"]["label_col"]], random_state=seed)
    return train.reset_index(drop=True), val.reset_index(drop=True), test.reset_index(drop=True)
