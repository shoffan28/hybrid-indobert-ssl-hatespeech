import re
import pandas as pd

def load_kamusalay_dict(path):
    slang = {}
    try:
        df = pd.read_csv(path, header=None, encoding="latin-1")
        for _, row in df.iterrows():
            if len(row) >= 2:
                slang[str(row.iloc[0]).strip()] = str(row.iloc[1]).strip()
    except Exception:
        pass
    return slang

def load_abusive_lexicon(path):
    try:
        df = pd.read_csv(path, header=None)
        return set(df.iloc[:, 0].astype(str).str.lower().tolist())
    except Exception:
        return set()

def normalize_repeated_chars(text, max_repeat=2):
    return re.sub(r"(.)\1{%d,}" % max_repeat, r"\1" * max_repeat, text)

def preprocess_text(text, slang_dict=None):
    slang_dict = slang_dict or {}
    text = str(text).lower()
    text = re.sub(r"http\\S+|www\\S+", " ", text)
    text = re.sub(r"@\\w+", " ", text)
    text = text.replace("#", " ")
    text = normalize_repeated_chars(text)
    text = re.sub(r"[^a-zA-Z0-9_@\\s]", " ", text)
    tokens = [slang_dict.get(tok, tok) for tok in text.split()]
    return " ".join(tokens).strip()
