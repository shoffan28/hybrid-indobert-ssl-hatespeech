import argparse, os, sys
import pandas as pd
sys.path.append(".")
from src.utils import load_config, ensure_dir
from src.evaluation.llm_eval import evaluate_openai_llm

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    parser.add_argument("--model", default="gpt-4o-mini")
    parser.add_argument("--split", default="test", choices=["val", "test"])
    parser.add_argument("--max_samples", type=int, default=500)
    args = parser.parse_args()
    cfg = load_config(args.config)
    out_dir = os.path.join(cfg["paths"]["results_dir"], "tables")
    ensure_dir(out_dir)
    df = pd.read_csv(os.path.join(cfg["paths"]["processed_dir"], f"{args.split}.csv"))
    if args.max_samples and len(df) > args.max_samples:
        df = df.sample(args.max_samples, random_state=cfg["seed"]).reset_index(drop=True)
    metrics, pred_df = evaluate_openai_llm(df, cfg["data"]["text_col"], cfg["data"]["label_col"], args.model)
    prefix = f"llm_{args.model}_{args.split}"
    pd.DataFrame([metrics]).to_csv(os.path.join(out_dir, f"{prefix}_metrics.csv"), index=False)
    pred_df.to_csv(os.path.join(out_dir, f"{prefix}_predictions.csv"), index=False)
    print(metrics)

if __name__ == "__main__":
    main()
