"""Entry point for baseline experiments. Add final executed baseline code here."""
import argparse
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    args = parser.parse_args()
    print("Run baseline experiments here: SVM, LR, RF, RFDT, CNN, LSTM, IndoBERT, mBERT, XLM-R, IndoBERTweet.")
    print("Expected output: results/tables/baseline_sota_results.csv")
if __name__ == "__main__":
    main()
