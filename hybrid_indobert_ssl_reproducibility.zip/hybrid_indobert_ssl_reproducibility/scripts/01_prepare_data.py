import argparse, os, sys
sys.path.append(".")
from src.utils import load_config, set_seed, ensure_dir
from src.data.loaders import prepare_full_dataset, make_splits

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default.yaml")
    args = parser.parse_args()
    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    ensure_dir(cfg["paths"]["processed_dir"])
    data, abusive = prepare_full_dataset(cfg)
    train, val, test = make_splits(data, cfg, seed=cfg["seed"])
    data.to_csv(os.path.join(cfg["paths"]["processed_dir"], "merged_clean.csv"), index=False)
    train.to_csv(os.path.join(cfg["paths"]["processed_dir"], "train_full.csv"), index=False)
    val.to_csv(os.path.join(cfg["paths"]["processed_dir"], "val.csv"), index=False)
    test.to_csv(os.path.join(cfg["paths"]["processed_dir"], "test.csv"), index=False)
    print(f"Merged={len(data)}, train={len(train)}, val={len(val)}, test={len(test)}")

if __name__ == "__main__":
    main()
